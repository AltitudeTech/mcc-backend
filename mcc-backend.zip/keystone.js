const keystone = require('keystone') ;

keystone.init({
    'name' : 'MCC Backend',
    'cookie secret' : 'secure string goes here',
    'auto update' : true ,
    'user model' : 'User',
    'auth' : true
});

keystone.import('models');

keystone.start() ;